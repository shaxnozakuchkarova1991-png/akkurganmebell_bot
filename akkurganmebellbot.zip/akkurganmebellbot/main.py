import asyncio
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from config import BOT_TOKEN
from keep_alive import keep_alive

# Handlers
from my_handlers import start, language, register, catalog, order,tracking,payment, products,help,admin_panel # ← BU YANGI QATOR

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())

# Routers ulash
dp.include_router(start.router)
dp.include_router(language.router)
dp.include_router(register.router)
dp.include_router(catalog.router) 
dp.include_router(order.router)
dp.include_router(tracking.router) 
dp.include_router(payment.router) 
dp.include_router(products.router)
dp.include_router(help.router) 
dp.include_router(admin_panel.router) # ← BU YANGI QATOR

# Run
async def main():
    await dp.start_polling(bot)

keep_alive()
asyncio.run(main())
