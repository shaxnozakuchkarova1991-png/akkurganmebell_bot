from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

main_menu_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🛒 Onlayn katalog"), KeyboardButton(text="📦 Buyurtma berish")],
        [KeyboardButton(text="🔎 Mening buyurtmalarim")],
        [KeyboardButton(text="💳 To‘lov"), KeyboardButton(text="🧾 Tayyor mahsulotlar")],
        [KeyboardButton(text="❓ Yordam")]
    ],
    resize_keyboard=True
)
