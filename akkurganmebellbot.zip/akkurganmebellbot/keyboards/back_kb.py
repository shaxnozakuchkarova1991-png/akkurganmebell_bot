from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

back_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="⬅️ Asosiy menyu")]
    ],
    resize_keyboard=True
)
