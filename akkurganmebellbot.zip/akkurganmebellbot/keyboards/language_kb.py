from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

language_kb = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🇺🇿 O'zbek"), KeyboardButton(text="🇷🇺 Русский")]
    ],
    resize_keyboard=True
)
