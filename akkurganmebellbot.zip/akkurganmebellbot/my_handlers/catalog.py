from aiogram import Router, F
from aiogram.types import Message

router = Router()

@router.message(F.text == "🛒 Onlayn katalog")
async def show_catalog(message: Message):
    await message.answer(
        "🛒 Bizning onlayn katalogimiz bilan tanishing 👇\n"
        "📦 To‘liq katalog: https://t.me/akkurgan_mebell255"
    )
