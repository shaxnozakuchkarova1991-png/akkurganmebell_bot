from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.state import StatesGroup, State
from config import ADMINS

router = Router()

class TrackingStates(StatesGroup):
    waiting_contract = State()

@router.message(F.text == "🔎 Mening buyurtmalarim")
async def ask_contract(message: Message, state: FSMContext):
    await message.answer("📄 Iltimos, buyurtmangiz shartnoma raqamini kiriting:")
    await state.set_state(TrackingStates.waiting_contract)

@router.message(TrackingStates.waiting_contract)
async def forward_contract_to_admin(message: Message, state: FSMContext):
    contract = message.text
    user_id = message.from_user.id
    full_name = message.from_user.full_name
    await state.clear()

    # 1-bosqich: admin shartnomani tasdiqlasin
    confirm_kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Buyurtma mavjud", callback_data=f"confirm_{user_id}_{contract}"),
            InlineKeyboardButton(text="❌ Topilmadi", callback_data=f"deny_{user_id}")
        ]
    ])

    for admin in ADMINS:
        await message.bot.send_message(
            chat_id=admin,
            text=f"🔍 Mijoz buyurtma so‘rovi:\n👤 {full_name}\n📄 Shartnoma: {contract}",
            reply_markup=confirm_kb
        )

    await message.answer("🕐 Shartnoma tekshirilmoqda. Admin tasdig‘ini kuting...")
