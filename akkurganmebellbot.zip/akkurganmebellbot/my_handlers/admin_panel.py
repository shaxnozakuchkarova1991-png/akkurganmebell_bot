# my_handlers/admin_panel.py

from aiogram import Router, types, F
from config import ADMINS
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

router = Router()

# /admin buyrug'i faqat adminlar uchun
@router.message(F.text == "/admin")
async def admin_menu(message: types.Message):
    if message.from_user.id in ADMINS:
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📋 Buyurtmalar", callback_data="admin_orders")],
            [InlineKeyboardButton(text="📢 Xabar yuborish", callback_data="admin_broadcast")],
            [InlineKeyboardButton(text="📊 Statistika", callback_data="admin_stats")]
        ])
        await message.answer("🔧 Admin menyusi:", reply_markup=keyboard)
    else:
        await message.answer("⛔ Sizda adminlik huquqi yo‘q.")
