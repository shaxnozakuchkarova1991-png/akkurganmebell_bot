from aiogram import Router, F, types
from aiogram.types import Message, FSInputFile, InlineKeyboardMarkup, InlineKeyboardButton

router = Router()

@router.message(F.text == "💳 To‘lov")  # ← Tugmaning aynan matniga mos!
async def show_payment_options(message: Message):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Naqd", callback_data="pay_cash")],
        [InlineKeyboardButton(text="Click", callback_data="pay_click")],
        [InlineKeyboardButton(text="Uzum", callback_data="pay_uzum")],
        [InlineKeyboardButton(text="Shartnoma", callback_data="pay_contract")]
    ])
    await message.answer("💳 Iltimos, to‘lov turini tanlang:", reply_markup=keyboard)

@router.callback_query(F.data.startswith("pay_"))
async def handle_callback(callback: types.CallbackQuery):
    if callback.data == "pay_cash":
        await callback.message.answer("💵 Naqd to‘lov tanlandi.")

    elif callback.data == "pay_click":
        await callback.message.answer("📲 Click raqami: +998 90 123 45 67")

    elif callback.data == "pay_uzum":
        try:
            photo = FSInputFile("images/uzum_qr.jpg")
            await callback.message.answer_photo(photo, caption="🏦 Uzum orqali to‘lov uchun QR kod.")
        except Exception as e:
            await callback.message.answer(f"❌ QR kodni yuborib bo‘lmadi: {e}")

    elif callback.data == "pay_contract":
        await callback.message.answer("📄 Onlayn shartnoma hozircha mavjud emas.")

    await callback.answer()
