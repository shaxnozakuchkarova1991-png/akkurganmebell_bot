# my_handlers/start.py

from aiogram import Router, F
from aiogram.types import Message
from keyboards.language_kb import language_kb

router = Router()

@router.message(F.text == "/start")
async def start_handler(message: Message):
    await message.answer(
        "👋 Assalomu alaykum! Bizning zamonaviy *AkkurganMebell_bot*imizga xush kelibsiz.\n\n"
        "Iltimos, o'zingiz uchun kerakli bo'lgan tilni tanlang:",
        reply_markup=language_kb
    )
