from aiogram import Router, F
from aiogram.types import Message
from keyboards.contact_kb import contact_kb

router = Router()

@router.message(F.text.in_(["🇺🇿 O'zbek", "🇷🇺 Русский"]))
async def language_selected(message: Message):
    await message.answer(
        "Iltimos, kontakt tugmasini bosib shaxsingizni tasdiqlang:",
        reply_markup=contact_kb
    )
