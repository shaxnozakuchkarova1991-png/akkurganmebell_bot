from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.state import StatesGroup, State
from config import ADMINS

router = Router()

class OrderStates(StatesGroup):
    contract = State()
    approved = State()
    address = State()
    phone = State()
    check = State()

@router.message(F.text == "📦 Buyurtma berish")
async def start_order(message: Message, state: FSMContext):
    await message.answer("📄 Iltimos, shartnoma raqamini kiriting:")
    await state.set_state(OrderStates.contract)

@router.message(OrderStates.contract)
async def contract_input(message: Message, state: FSMContext):
    contract = message.text
    user_id = message.from_user.id
    await state.update_data(contract=contract, user_id=user_id)

    # Tugmalar: Tasdiqlash / Rad etish
    inline_kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"approve_{user_id}"),
            InlineKeyboardButton(text="❌ Rad etish", callback_data=f"reject_{user_id}")
        ]
    ])

    for admin_id in ADMINS:
        await message.bot.send_message(
            chat_id=admin_id,
            text=f"📝 Yangi buyurtma so‘rovi:\n👤 {message.from_user.full_name}\n📄 Shartnoma: {contract}",
            reply_markup=inline_kb
        )

    await message.answer("🕐 Admin tasdig‘ini kuting...")
    await state.set_state(OrderStates.approved)

@router.callback_query(F.data.startswith("approve_"))
async def approve_order(callback: CallbackQuery, state: FSMContext):
    user_id = int(callback.data.split("_")[1])
    await callback.bot.send_message(user_id, "✅ Buyurtmangiz tasdiqlandi. Endi manzilni yuboring:")
    await callback.message.edit_reply_markup(reply_markup=None)

    # Foydalanuvchi holatini yangilaymiz
    await state.set_state(OrderStates.address)

@router.callback_query(F.data.startswith("reject_"))
async def reject_order(callback: CallbackQuery, state: FSMContext):
    user_id = int(callback.data.split("_")[1])
    await callback.bot.send_message(user_id, "❌ Buyurtmangiz rad etildi. Iltimos, shartnoma raqamini qayta tekshiring.")
    await callback.message.edit_reply_markup(reply_markup=None)

    # Holatni tozalaymiz
    await state.clear()
