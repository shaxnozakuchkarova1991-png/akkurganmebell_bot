# my_handlers/help.py

from aiogram import Router, types, F
from aiogram.types import Message
from config import ADMINS

router = Router()

# ❓ Yordam tugmasi bosilganda
@router.message(F.text == "❓ Yordam")
async def ask_help(message: Message):
    await message.answer("🆘 Iltimos, muammo yoki savolingizni yozib yuboring. Tez orada administrator siz bilan bog‘lanadi.")

    # Adminga avtomatik xabar
    for admin_id in ADMINS:
        await message.bot.send_message(
            admin_id,
            f"📥 Yordam so‘rovi:\n👤 {message.from_user.full_name} (ID: {message.from_user.id})\n"
            f"Username: @{message.from_user.username or 'yo‘q'}\n\n❓ Tugmani bosdi, so‘rov kutilyapti..."
        )

# Foydalanuvchi yozgan matnni adminga uzatish
@router.message(F.text)
async def forward_user_help(message: Message):
    for admin_id in ADMINS:
        await message.bot.send_message(
            admin_id,
            f"🆘 Yordam so‘rovi\n👤 {message.from_user.full_name} (ID: {message.from_user.id})\n"
            f"✉️ Xabar: {message.text}"
        )
    await message.answer("✅ So‘rovingiz adminga yuborildi. Javobni kuting.")
