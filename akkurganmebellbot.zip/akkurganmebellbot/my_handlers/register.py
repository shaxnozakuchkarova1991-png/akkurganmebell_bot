from aiogram import Router
from aiogram.types import Message
from config import ADMINS
from keyboards.main_menu_kb import main_menu_kb

router = Router()

@router.message(lambda msg: msg.contact is not None)
async def register_user(message: Message):
    contact = message.contact
    text = (
        f"📥 Yangi foydalanuvchi ro‘yxatdan o‘tdi:\n\n"
        f"Ismi: {contact.first_name}\n"
        f"Familiyasi: {contact.last_name or 'yo‘q'}\n"
        f"Telefon raqami: {contact.phone_number}\n"
        f"Telegram ID: {contact.user_id}"
    )

    for admin_id in ADMINS:
        await message.bot.send_message(chat_id=admin_id, text=text)

    await message.answer("✅ Ro’yxatdan muvaffaqiyatli o‘tdingiz!")
    await message.answer("👇 Asosiy menyu:", reply_markup=main_menu_kb)
