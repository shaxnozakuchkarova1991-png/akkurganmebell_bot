# my_handlers/products.py

from aiogram import Router, types
from aiogram.types import Message

router = Router()

@router.message(lambda msg: msg.text == "🧾 Tayyor mahsulotlar")
async def show_products(message: Message):
    await message.answer(
        "🧾 Tayyor mahsulotlar bilan tanishing:\n\n"
        "👉 [Havola orqali o‘ting](https://t.me/+hQNGRd7sbOxjMDNi)",
        disable_web_page_preview=True,
        parse_mode="Markdown"
    )
